import logging
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path

LOGS_DIR = Path(__file__).resolve().parent.parent / "logs"
LOGS_DIR.mkdir(exist_ok=True)


def get_logger(name: str, file_name: str, level=logging.INFO):
    logger = logging.getLogger(name)

    # Prevent duplicate handlers
    if logger.handlers:
        return logger

    logger.setLevel(level)

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s:%(lineno)d | %(message)s",
        "%Y-%m-%d %H:%M:%S",
    )

    # File handler (auto-rotate + auto-delete after 2 days)
    file_handler = TimedRotatingFileHandler(
        filename=LOGS_DIR / f"{file_name}.log",
        when="midnight",
        interval=1,
        backupCount=2,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)

    # 🖥 Console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger