import logging
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from backend.config.logging_config import get_logger
from backend.connection.database import get_db
from backend.models.notification import Notification
from backend.models.user import User
from backend.services.auth_service import get_current_user  

router = APIRouter(prefix="/notifications", tags=["Notifications"])

# Here is teh exmpale if wnat to add for all teh routes:->  router = APIRouter(prefix="/notifications", tags=["Notifications"],dependencies=[Depends(get_current_user)])
# Otherwise we can add the Depends(get_current_user) for each route as shown below


logger = get_logger(__name__, "notifications")


# -------------------- GET ALL --------------------

@router.get("")
def get_notifications(
    read: bool | None = Query(default=None),
    page: int = 1,
    limit: int = 10,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    query = db.query(Notification).filter(
        Notification.user_id == user.id
    )

    if read is not None:
        query = query.filter(Notification.is_read == read)

    notifications = query.order_by(
        Notification.created_at.desc()
    ).offset((page - 1) * limit).limit(limit).all()

    unread_count = db.query(Notification).filter(
        Notification.user_id == user.id,
        Notification.is_read == False
    ).count()

    return {
        "data": notifications,
        "unread_count": unread_count
    }

# -------------------- MARK ALL --------------------

@router.put("/read-all")
def mark_all_read(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    updated_count = db.query(Notification).filter(
        Notification.user_id == user.id,
        Notification.is_read == False
    ).update({"is_read": True})

    db.commit()

    return {
        "message": "All notifications marked as read",
        "updated_count": updated_count
    }


# -------------------- MARK SINGLE --------------------

@router.put("/{id}/read")
def mark_as_read(
    id: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    notification = db.query(Notification).filter(
        Notification.id == id,
        Notification.user_id == user.id
    ).first()

    if not notification:
        raise HTTPException(status_code=404, detail="Notification not found")

    notification.is_read = True
    db.commit()

    return {"message": "Marked as read"}


