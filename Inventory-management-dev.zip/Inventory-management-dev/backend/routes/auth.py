import logging
from datetime import datetime, timedelta

from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from backend.connection.database import get_db
from backend.models.user import User
from backend.models.refresh_token import RefreshToken
from backend.schema.user import UserCreate, UserLogin, UserOut,RefreshTokenRequest
from jose import JWTError, ExpiredSignatureError
from backend.services.auth_service import (
    hash_password,
    verify_password,
    create_access_token,
    create_refresh_token,
    decode_token
)
from backend.config.logging_config import get_logger
from backend.config.settings import settings


logger = get_logger(__name__, "auth")

router = APIRouter(prefix="/auth", tags=["Auth"])


# -------------------- SIGNUP --------------------

@router.post("/signup", response_model=UserOut, status_code=201)
def signup(payload: UserCreate, db: Session = Depends(get_db)):
    logger.info("Signup request received for email: %s", payload.email)

    email = payload.email.lower().strip()

    try:
        existing_user = db.query(User).filter(User.email == email).first()

        if existing_user:
            logger.warning("Signup failed: email already exists: %s", email)
            raise HTTPException(status_code=409, detail="Email already exists")

        hashed_password = hash_password(payload.password)

        new_user = User(
            name=payload.name,
            email=email,
            password_hash=hashed_password,
            role=payload.role,
            contact=payload.contact
        )

        db.add(new_user)
        db.commit()
        db.refresh(new_user)

        logger.info("User created successfully with id: %s", new_user.id)

        return new_user

    except Exception as e:
        logger.exception("Signup failed for email: %s", email)
        raise


# -------------------- LOGIN --------------------

@router.post("/login")
def login(payload: UserLogin, db: Session = Depends(get_db)):
    logger.info("Login request received for email: %s", payload.email)

    email = payload.email.lower().strip()

    try:
        user = db.query(User).filter(User.email == email).first()

        if not user:
            logger.warning("Login failed: user not found for email: %s", email)
            raise HTTPException(status_code=401, detail="Invalid credentials")

        if not verify_password(payload.password, user.password_hash):
            logger.warning("Login failed: incorrect password for user_id: %s", user.id)
            raise HTTPException(status_code=401, detail="Invalid credentials")

        token_data = {
            "sub": str(user.id),
            "role": user.role
        }

        access_token = create_access_token(token_data)
        refresh_token = create_refresh_token(token_data)

        decoded = decode_token(refresh_token)

        db.add(
            RefreshToken(
                user_id=user.id,
                token=decoded["jti"],
                expires_at=datetime.utcnow() + timedelta(days=7)
            )
        )
        db.commit()

        logger.info("Login successful for user_id: %s", user.id)

        return {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": "bearer",
            "user": {
                "id": user.id,
                "name": user.name,
                "email": user.email,
                "role": user.role
            }
        }

    except HTTPException:
        raise
    except Exception:
        logger.exception("Unexpected error during login for email: %s", email)
        raise HTTPException(status_code=500, detail="Internal server error")


# -------------------- REFRESH --------------------
@router.post("/refresh")
def refresh_token_endpoint(
    request: RefreshTokenRequest,
    db: Session = Depends(get_db)
):
    logger.info("Refresh token request received")

    try:
        payload = decode_token(request.refresh_token)

    except ExpiredSignatureError:
        logger.warning("Refresh failed: token expired (JWT)")
        raise HTTPException(401, "Token expired")

    except JWTError:
        logger.warning("Refresh failed: invalid token")
        raise HTTPException(401, "Invalid token")

    try:
        if payload.get("type") != "refresh":
            raise HTTPException(401, "Invalid token")

        jti = payload.get("jti")

        token_entry = db.query(RefreshToken).filter(
            RefreshToken.token == jti
        ).first()

        if not token_entry:
            raise HTTPException(401, "Invalid token")

        # DB expiry uses same config
        if token_entry.expires_at < datetime.utcnow():
            db.delete(token_entry)
            db.commit()
            raise HTTPException(401, "Token expired")

        user_id = int(payload["sub"])

        logger.info("Rotating refresh token for user_id: %s", user_id)

        db.delete(token_entry)

        new_data = {
            "sub": payload["sub"],
            "role": payload["role"]
        }

        new_access = create_access_token(new_data)
        new_refresh = create_refresh_token(new_data)

        decoded_new = decode_token(new_refresh)

        db.add(
            RefreshToken(
                user_id=user_id,
                token=decoded_new["jti"],
                expires_at=datetime.utcnow()
                + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
            )
        )

        db.commit()

        return {
            "access_token": new_access,
            "refresh_token": new_refresh
        }

    except HTTPException:
        raise

    except Exception:
        logger.exception("Unexpected error during refresh")
        raise HTTPException(500, "Internal server error")
    
# -------------------- LOGOUT --------------------
@router.post("/logout")
def logout(
    request: RefreshTokenRequest,
    db: Session = Depends(get_db)
):
    logger.info("Logout request received")

    try:
        payload = decode_token(request.refresh_token)

    except ExpiredSignatureError:
        logger.warning("Logout with expired token")
        raise HTTPException(401, "Token expired")

    except JWTError:
        logger.warning("Logout with invalid token")
        raise HTTPException(401, "Invalid token")

    try:
        jti = payload.get("jti")

        deleted = db.query(RefreshToken).filter(
            RefreshToken.token == jti
        ).delete()

        db.commit()

        if deleted:
            logger.info("Logout successful")
        else:
            logger.warning("Logout attempted with non-existing token")

        return {"message": "Logged out successfully"}

    except Exception:
        logger.exception("Error during logout")
        raise HTTPException(500, "Internal server error")