
from backend.models.notification import Notification
from sqlalchemy.orm import Session

def create_notification(
    db: Session,
    user_id: int,
    title: str,
    message: str,
    entity_type: str = None,
    entity_id: int = None
):
    db.add(Notification(
        user_id=user_id,
        title=title,
        message=message,
        entity_type=entity_type,
        entity_id=entity_id
    ))



# how to Use
# create_notification(
#     db,
#     user_id=request.requested_by,
#     title="New Request",
#     message=f"REQ-{request.id} created",
#     entity_type="request",
#     entity_id=request.id
# )