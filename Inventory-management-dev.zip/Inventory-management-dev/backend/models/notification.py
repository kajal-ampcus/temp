from __future__ import annotations
from sqlalchemy import (
    DateTime,
    ForeignKey,
    Integer,
    func,
    String,
    Boolean,
    Text,
    
)
from sqlalchemy.orm import  mapped_column
from backend.models.base import Base


class Notification(Base):
    __tablename__ = "notifications"

    id = mapped_column(Integer, primary_key=True)

    user_id = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False
    )

    title = mapped_column(Text, nullable=False)
    message = mapped_column(Text, nullable=False)

    is_read = mapped_column(Boolean, default=False)

    entity_type = mapped_column(String, nullable=True)   # "request", "stock", "order"
    entity_id = mapped_column(Integer, nullable=True)

    created_at = mapped_column(DateTime, server_default=func.now())