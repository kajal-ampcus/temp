from __future__ import annotations
from sqlalchemy import (
    Integer,
    String,
    Boolean,
    ForeignKey,
    UniqueConstraint
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from backend.models.base import Base


class Category(Base):
    __tablename__ = "categories"

    id        : Mapped[int]  = mapped_column(Integer, primary_key=True)
    name      : Mapped[str]  = mapped_column(String(100), nullable=False)
    is_active : Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")

    parent_id : Mapped[int | None] = mapped_column(
        ForeignKey("categories.id", ondelete="CASCADE"),
        nullable=True
    )

    __table_args__ = (
        UniqueConstraint("name", "parent_id", name="uq_category_name_parent"),
    )

    # relationships
    parent   : Mapped["Category | None"] = relationship(
        remote_side=[id],
        backref="children"
    )

    products: Mapped[list[Product]] = relationship(
        back_populates="category",
        cascade="all, delete-orphan"
    )