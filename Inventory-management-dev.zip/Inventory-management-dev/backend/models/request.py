from __future__ import annotations
import enum
from datetime import datetime,date
from sqlalchemy import (
    CheckConstraint,
    DateTime,
    ForeignKey,
    Integer,
    func,
    Enum as SAEnum,
    Text,
    Date
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from backend.models.base import Base

class PriorityLevel(str, enum.Enum):
    high   = "high"
    medium = "medium"
    low    = "low"


class RequestStatus(str, enum.Enum):
    PENDING  = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    ISSUED   = "ISSUED"


class ApprovalStatus(str, enum.Enum):
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    MODIFIED = "MODIFIED"


class Request(Base):
    __tablename__ = "requests"

    id           : Mapped[int]           = mapped_column(Integer, primary_key=True)
    requested_by : Mapped[int | None]    = mapped_column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    status       : Mapped[RequestStatus] = mapped_column(
        SAEnum(RequestStatus, name="request_status"),
        default=RequestStatus.PENDING,
        server_default="PENDING",
    )
    priority     : Mapped[PriorityLevel] = mapped_column(
        SAEnum(PriorityLevel, name="priority_level"),
        default=PriorityLevel.medium,
        server_default="medium",
    )
    reason       : Mapped[str | None]    = mapped_column(Text)
    request_date : Mapped[date | None]   = mapped_column(Date, server_default=func.current_date())
    created_at   : Mapped[datetime]      = mapped_column(DateTime, server_default=func.now())

    # relationships
    requester : Mapped[User | None]           = relationship(back_populates="requests")
    items     : Mapped[list[RequestItem]]     = relationship(back_populates="request", cascade="all, delete-orphan")
    approvals : Mapped[list[RequestApproval]] = relationship(back_populates="request", cascade="all, delete-orphan")


# ── Request Items ─────────────────────────────────────────────────────────────


class RequestItem(Base):
    __tablename__ = "request_items"
    __table_args__ = (
        CheckConstraint("requested_quantity > 0",  name="chk_req_item_qty_positive"),
        CheckConstraint("approved_quantity >= 0",  name="chk_req_item_approved_non_negative"),
        CheckConstraint("fulfilled_quantity >= 0", name="chk_req_item_fulfilled_non_negative"),
    )

    id                 : Mapped[int]        = mapped_column(Integer, primary_key=True)
    request_id         : Mapped[int]        = mapped_column(Integer, ForeignKey("requests.id",  ondelete="CASCADE"),  nullable=False)
    product_id         : Mapped[int]        = mapped_column(Integer, ForeignKey("products.id",  ondelete="RESTRICT"), nullable=False)
    requested_quantity : Mapped[int]        = mapped_column(Integer, nullable=False)
    approved_quantity  : Mapped[int | None] = mapped_column(Integer)
    fulfilled_quantity : Mapped[int]        = mapped_column(Integer, default=0, server_default="0")

    # relationships
    request            : Mapped[Request]                = relationship(back_populates="items")
    product            : Mapped[Product]                = relationship(back_populates="request_items")
    stock_transactions : Mapped[list[StockTransaction]] = relationship(back_populates="request_item")


# ── Request Approvals ─────────────────────────────────────────────────────────


class RequestApproval(Base):
    __tablename__ = "request_approvals"

    id              : Mapped[int]            = mapped_column(Integer, primary_key=True)
    request_id      : Mapped[int]            = mapped_column(Integer, ForeignKey("requests.id", ondelete="CASCADE"),  nullable=False)
    approved_by     : Mapped[int | None]     = mapped_column(Integer, ForeignKey("users.id",    ondelete="SET NULL"))
    approval_status : Mapped[ApprovalStatus] = mapped_column(SAEnum(ApprovalStatus, name="approval_status"), nullable=False)
    remarks         : Mapped[str | None]     = mapped_column(Text)
    approval_date   : Mapped[datetime]       = mapped_column(DateTime, server_default=func.now())

    # relationships
    request  : Mapped[Request]     = relationship(back_populates="approvals")
    approver : Mapped[User | None] = relationship(back_populates="approvals")