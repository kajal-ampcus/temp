from __future__ import annotations
from datetime import datetime
from sqlalchemy import (
    DateTime,
    ForeignKey,
    Integer,
    String,
    func,
    Text
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from backend.models.base import Base




class AuditLog(Base):
    __tablename__ = "audit_logs"

    id          : Mapped[int]        = mapped_column(Integer, primary_key=True)
    user_id     : Mapped[int | None] = mapped_column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    action_type : Mapped[str | None] = mapped_column(String(50))
    entity_name : Mapped[str | None] = mapped_column(String(50))
    entity_id   : Mapped[int | None] = mapped_column(Integer)
    action_date : Mapped[datetime]   = mapped_column(DateTime, server_default=func.now())
    description : Mapped[str | None] = mapped_column(Text)

    # relationships
    user: Mapped[User | None] = relationship(back_populates="audit_logs")