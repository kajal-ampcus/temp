from __future__ import annotations
from datetime import datetime,date
from decimal import Decimal
from sqlalchemy import (
    CheckConstraint,
    DateTime,
    ForeignKey,
    Integer,
    Numeric,
    Date,
    Computed,
    func
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from backend.models.base import Base



class InventoryBatch(Base):
    __tablename__ = "inventory_batches"
    __table_args__ = (
        CheckConstraint("quantity > 0",                    name="chk_batch_qty_positive"),
        CheckConstraint("quantity_available >= 0",         name="chk_batch_avail_non_negative"),
        CheckConstraint("unit_cost >= 0",                  name="chk_batch_cost_non_negative"),
        CheckConstraint("quantity_available <= quantity",  name="chk_available_lte_qty"),
    )

    id                 : Mapped[int]            = mapped_column(Integer, primary_key=True)
    product_id         : Mapped[int]            = mapped_column(Integer, ForeignKey("products.id", ondelete="CASCADE"),  nullable=False)
    vendor_id          : Mapped[int | None]     = mapped_column(Integer, ForeignKey("vendors.id",  ondelete="SET NULL"))
    quantity           : Mapped[int]            = mapped_column(Integer, nullable=False)
    quantity_available : Mapped[int]            = mapped_column(Integer, nullable=False)
    unit_cost          : Mapped[Decimal | None] = mapped_column(Numeric(10, 2))
    # total_cost is a GENERATED ALWAYS AS (quantity * unit_cost) STORED column in Postgres.
    # Mapped as server-side read-only — never written by the ORM.
    total_cost: Mapped[Decimal | None] = mapped_column(
        Numeric(12, 2),
        Computed("quantity * unit_cost")
    )
    purchase_date      : Mapped[date | None]    = mapped_column(Date, server_default=func.current_date())
    expiry_date        : Mapped[date | None]    = mapped_column(Date)
    created_at         : Mapped[datetime]       = mapped_column(DateTime, server_default=func.now())

    # relationships
    product            : Mapped[Product]                = relationship(back_populates="inventory_batches")
    vendor             : Mapped[Vendor | None]          = relationship(back_populates="inventory_batches")
    stock_transactions : Mapped[list[StockTransaction]] = relationship(back_populates="batch")
