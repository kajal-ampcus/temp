from __future__ import annotations
from datetime import datetime
from backend.models.base import Base
from sqlalchemy import (
    Boolean,
    DateTime,
    Integer,
    String,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship





class User(Base):
    __tablename__ = "users"

    id            : Mapped[int]        = mapped_column(Integer, primary_key=True)
    name          : Mapped[str]        = mapped_column(String(100), nullable=False)
    email         : Mapped[str]        = mapped_column(String(100), unique=True, nullable=False)
    role          : Mapped[str]        = mapped_column(String(50),  nullable=False)
    password_hash : Mapped[str]        = mapped_column(String(255), nullable=False)
    contact       : Mapped[str | None] = mapped_column(String(50))
    is_active     : Mapped[bool]       = mapped_column(Boolean, default=True,     server_default="true")
    created_at    : Mapped[datetime]   = mapped_column(DateTime, server_default=func.now())

    # relationships
    requests           : Mapped[list[Request]]          = relationship(back_populates="requester")
    approvals          : Mapped[list[RequestApproval]]  = relationship(back_populates="approver")
    stock_transactions : Mapped[list[StockTransaction]] = relationship(back_populates="performer")
    audit_logs         : Mapped[list[AuditLog]]         = relationship(back_populates="user")

