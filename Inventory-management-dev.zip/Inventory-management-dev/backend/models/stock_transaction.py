from __future__ import annotations
import enum
from datetime import datetime

from sqlalchemy import (
    CheckConstraint,
    DateTime,
    ForeignKey,
    Integer,
    func,
    Enum as SAEnum
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from backend.models.base import Base


class TransactionType(str, enum.Enum):
    PURCHASE = "PURCHASE"
    ISSUE    = "ISSUE"

class StockTransaction(Base):
    __tablename__ = "stock_transactions"
    __table_args__ = (
        CheckConstraint("quantity > 0", name="chk_tx_qty_positive"),
    )

    id               : Mapped[int]             = mapped_column(Integer, primary_key=True)
    batch_id         : Mapped[int]             = mapped_column(Integer, ForeignKey("inventory_batches.id", ondelete="RESTRICT"), nullable=False)
    product_id       : Mapped[int]             = mapped_column(Integer, ForeignKey("products.id",          ondelete="RESTRICT"), nullable=False)
    request_item_id  : Mapped[int | None]      = mapped_column(Integer, ForeignKey("request_items.id",     ondelete="SET NULL"))
    transaction_type : Mapped[TransactionType] = mapped_column(SAEnum(TransactionType, name="transaction_type"), nullable=False)
    quantity         : Mapped[int]             = mapped_column(Integer, nullable=False)
    performed_by     : Mapped[int | None]      = mapped_column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    created_at       : Mapped[datetime]        = mapped_column(DateTime, server_default=func.now())

    # relationships
    batch        : Mapped[InventoryBatch]      = relationship(back_populates="stock_transactions")
    product      : Mapped[Product]             = relationship(back_populates="stock_transactions")
    request_item : Mapped[RequestItem | None]  = relationship(back_populates="stock_transactions")
    performer    : Mapped[User | None]         = relationship(back_populates="stock_transactions")
