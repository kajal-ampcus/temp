from datetime import datetime
from sqlalchemy import ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from backend.models.base import Base


class RefreshToken(Base):
    __tablename__ = "refresh_tokens"

    id: Mapped[int] = mapped_column(primary_key=True)

    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))

    token: Mapped[str] = mapped_column(nullable=False)  # store jti

    expires_at: Mapped[datetime]

    created_at: Mapped[datetime] = mapped_column(default=datetime.utcnow)

    user = relationship("User")