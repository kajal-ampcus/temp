from __future__ import annotations
from datetime import datetime
from decimal import Decimal

from sqlalchemy import (
    CheckConstraint,
    DateTime,
    ForeignKey,
    Integer,
    func,
    Text,
    Numeric,
    Boolean,
    String,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from backend.models.base import Base



class VendorProduct(Base):
    __tablename__ = "vendor_products"
    __table_args__ = (
        UniqueConstraint("vendor_id", "product_id", name="uq_vendor_product"),
        CheckConstraint("unit_cost >= 0", name="chk_vendor_product_cost_non_negative"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    vendor_id: Mapped[int] = mapped_column(
        ForeignKey("vendors.id", ondelete="CASCADE"), nullable=False
    )
    product_id: Mapped[int] = mapped_column(
        ForeignKey("products.id", ondelete="CASCADE"), nullable=False
    )
    unit_cost: Mapped[Decimal | None] = mapped_column(Numeric(10, 2))
    is_active: Mapped[bool] = mapped_column(default=True, server_default="true")

    vendor: Mapped[Vendor] = relationship(back_populates="vendor_products")
    product: Mapped[Product] = relationship(back_populates="vendor_products")


class Vendor(Base):
    __tablename__ = "vendors"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    contact: Mapped[str | None] = mapped_column(String(50))
    address: Mapped[str | None] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(default=True, server_default="true")
    created_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now()
    )

    vendor_products: Mapped[list[VendorProduct]] = relationship(
        back_populates="vendor"
    )
    inventory_batches: Mapped[list[InventoryBatch]] = relationship(
        back_populates="vendor"
    )