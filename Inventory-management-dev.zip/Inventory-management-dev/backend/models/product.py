from __future__ import annotations
from datetime import datetime
from sqlalchemy import (
    Boolean,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Integer,
    String,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from backend.models.base import Base


class Product(Base):
    __tablename__ = "products"
    __table_args__ = (
        CheckConstraint("shelf_life_days > 0",  name="chk_shelf_life_positive"),
        CheckConstraint("min_stock_level >= 0", name="chk_min_stock_non_negative"),
    )

    id              : Mapped[int]        = mapped_column(Integer, primary_key=True)
    name            : Mapped[str]        = mapped_column(String(100), nullable=False)
    category_id     : Mapped[int | None] = mapped_column(Integer, ForeignKey("categories.id", ondelete="SET NULL"))
    unit            : Mapped[str | None] = mapped_column(String(20))
    shelf_life_days : Mapped[int | None] = mapped_column(Integer)
    min_stock_level : Mapped[int]        = mapped_column(Integer, default=0, server_default="0")
    brand_name      : Mapped[str | None] = mapped_column(String(50))
    is_active       : Mapped[bool]       = mapped_column(Boolean, default=True, server_default="true")
    created_at      : Mapped[datetime]   = mapped_column(DateTime, server_default=func.now())

    # relationships — quoted strings, no imports needed for related models
    category           : Mapped[Category | None]        = relationship(back_populates="products")
    vendor_products    : Mapped[list[VendorProduct]]    = relationship(back_populates="product")
    inventory_batches  : Mapped[list[InventoryBatch]]   = relationship(back_populates="product")
    request_items      : Mapped[list[RequestItem]]      = relationship(back_populates="product")
    stock_transactions : Mapped[list[StockTransaction]] = relationship(back_populates="product")