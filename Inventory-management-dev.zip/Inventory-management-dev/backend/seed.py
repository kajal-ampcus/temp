
import sys
import argparse
from datetime import date, timedelta
import bcrypt
import psycopg2
from psycopg2.extras import RealDictCursor

# ─────────────────────────────────────────────────────────────
#  DB CONFIG (FROM .env)
# ─────────────────────────────────────────────────────────────
DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "dbname": "inventory_management",
    "user": "postgres",
    "password": "admin@123"
}

# ─────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────

def get_connection():
    return psycopg2.connect(**DB_CONFIG)

def hpw(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

today = date.today()
d = lambda n: today + timedelta(days=n)

def log(msg, quiet):
    if not quiet:
        print(msg)

# ─────────────────────────────────────────────────────────────
# RESET
# ─────────────────────────────────────────────────────────────

def reset_all(cur, quiet):
    tables = [
        "audit_logs", "notifications", "request_approvals",
        "stock_transactions", "request_items", "requests",
        "inventory_batches", "vendor_products", "products",
        "vendors", "categories", "users",
    ]
    for t in tables:
        cur.execute(f"TRUNCATE TABLE {t} RESTART IDENTITY CASCADE")
    log(" All tables truncated", quiet)

# ─────────────────────────────────────────────────────────────
# SEED USERS
# ─────────────────────────────────────────────────────────────

def seed_users(cur, quiet):
    users = [
        ("Rahul Sharma", "rahul@kitchen.com", "store", hpw("Store@1234")),
        ("Priya Mehta", "priya@kitchen.com", "store", hpw("Store@1234")),
        ("Chef Arjun", "arjun@kitchen.com", "chef", hpw("Chef@1234")),
        ("Chef Sneha", "sneha@kitchen.com", "chef", hpw("Chef@1234")),
    ]

    ids = {}

    for name, email, role, pw in users:
        cur.execute("""
            INSERT INTO users (name, email, role, password_hash, contact, is_active)
            VALUES (%s, %s, %s, %s, %s, TRUE)
            ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name
            RETURNING id
        """, (name, email, role, pw, "9800000000"))

        ids[email] = cur.fetchone()["id"]
        log(f" {name}", quiet)

    return ids

# ─────────────────────────────────────────────────────────────
# SEED CATEGORIES
# ─────────────────────────────────────────────────────────────

def seed_categories(cur, quiet):
    categories = [
        "Grains", "Pulses", "Dairy", "Spices",
        "Oils", "Vegetables", "Beverages",
        "Frozen Foods", "Condiments"
    ]

    ids = {}

    for name in categories:
        cur.execute("""
            INSERT INTO categories (name, is_active)
            VALUES (%s, TRUE)
            ON CONFLICT (name) DO NOTHING
            RETURNING id
        """, (name,))

        row = cur.fetchone()
        if row:
            ids[name] = row["id"]
        else:
            cur.execute("SELECT id FROM categories WHERE name=%s", (name,))
            ids[name] = cur.fetchone()["id"]

        log(f" {name}", quiet)

    return ids

# ─────────────────────────────────────────────────────────────
# SEED VENDORS
# ─────────────────────────────────────────────────────────────

def seed_vendors(cur, quiet):
    vendors = [
        ("Fresh Farms Ltd", "9811111111"),
        ("Spice World Traders", "9822222222"),
        ("DairyBest Pvt Ltd", "9833333333"),
    ]

    ids = {}

    for name, contact in vendors:
        cur.execute("""
            INSERT INTO vendors (name, contact, is_active)
            VALUES (%s, %s, TRUE)
            ON CONFLICT DO NOTHING
            RETURNING id
        """, (name, contact))

        row = cur.fetchone()
        if row:
            ids[name] = row["id"]
        else:
            cur.execute("SELECT id FROM vendors WHERE name=%s", (name,))
            ids[name] = cur.fetchone()["id"]

        log(f" {name}", quiet)

    return ids

# ─────────────────────────────────────────────────────────────
# SEED PRODUCTS
# ─────────────────────────────────────────────────────────────

def seed_products(cur, cat, quiet):
    products = [
        ("Basmati Rice", "Grains"),
        ("Milk", "Dairy"),
        ("Paneer", "Dairy"),
        ("Tomatoes", "Vegetables"),
    ]

    ids = {}

    for name, category in products:
        cur.execute("""
            INSERT INTO products (name, category_id, unit, is_active)
            VALUES (%s, %s, 'KG', TRUE)
            ON CONFLICT DO NOTHING
            RETURNING id
        """, (name, cat[category]))

        row = cur.fetchone()
        if row:
            ids[name] = row["id"]
        else:
            cur.execute("SELECT id FROM products WHERE name=%s", (name,))
            ids[name] = cur.fetchone()["id"]

        log(f"{name}", quiet)

    return ids

# ─────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--reset", action="store_true")
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()

    print("\nSeeding Database...\n")

    conn = get_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)

    try:
        if args.reset:
            reset_all(cur, args.quiet)

        users = seed_users(cur, args.quiet)
        cats = seed_categories(cur, args.quiet)
        vendors = seed_vendors(cur, args.quiet)
        products = seed_products(cur, cats, args.quiet)

        conn.commit()

        print("\n Seeding Complete!")

    except Exception as e:
        conn.rollback()
        print(" Error:", e)

    finally:
        cur.close()
        conn.close()

# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    main()