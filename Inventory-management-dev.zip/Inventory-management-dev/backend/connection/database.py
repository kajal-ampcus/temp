from contextlib import contextmanager
from typing import Generator
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from urllib.parse import quote_plus
from backend.config.settings import settings

password = quote_plus(settings.DB_PASSWORD)
DATABASE_URL = (
    f"postgresql+psycopg2://{settings.DB_USER}:{password}"
    f"@{settings.DB_HOST}:{settings.DB_PORT}/{settings.DB_NAME}"
)

engine = create_engine(
    DATABASE_URL,
    pool_size=settings.DB_MIN_CONN,
    max_overflow=settings.DB_MAX_CONN - settings.DB_MIN_CONN,
    pool_pre_ping=True,       # drops stale connections before use
    pool_recycle=1800,        # recycle connections every 30 min
)

SessionLocal = sessionmaker(
    bind=engine,
    autocommit=False,
    autoflush=False,
    expire_on_commit=False,   # objects stay usable after commit
)


@contextmanager
def get_session() -> Generator[Session, None, None]:
    """Context manager for use in services / scripts."""
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency — use with Depends(get_db)."""
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()