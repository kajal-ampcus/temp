from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from backend.connection.database import engine
from backend.models import Base
from backend.routes import auth,notifications
from backend.config.logging_config import get_logger

logger = get_logger(__name__, "main")


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Creates any tables not yet in the DB — safe to run on every startup
    Base.metadata.create_all(bind=engine)
    yield

app = FastAPI(
    title="KitchenLedger API",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/api/auth", tags=["Auth"])
app.include_router(notifications.router, prefix="/api/notifications", tags=["Notifications"])